﻿using Microsoft.Toolkit.Uwp.Input.GazeInteraction;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Input.Preview;
using System.Diagnostics;
using Windows.Storage;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Dyslexie_Herkenning_App
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BlankPage1 : Page
    {
        public object Timmer { get; private set; }

        public BlankPage1()
        {
            this.InitializeComponent();
        }

        //NAVIGATIE BAR
        private void MainPageButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }
        private void BlankPage1Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage1));
        }
        private void BlankPage2Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage2));
        }
        private void BlankPage3Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage3));
        }


        /// <summary>
        /// Alle stopwatches voor elk woord
        /// </summary>
        Stopwatch Woord1Stopwatch = new Stopwatch();
        Stopwatch Woord2Stopwatch = new Stopwatch();
        Stopwatch Woord3Stopwatch = new Stopwatch();
        Stopwatch Woord4Stopwatch = new Stopwatch();
        Stopwatch Woord5Stopwatch = new Stopwatch();
        Stopwatch Woord6Stopwatch = new Stopwatch();
        Stopwatch Woord7Stopwatch = new Stopwatch();
        Stopwatch Woord8Stopwatch = new Stopwatch();
        Stopwatch Woord9Stopwatch = new Stopwatch();
        Stopwatch Woord10Stopwatch = new Stopwatch();
        Stopwatch Woord11Stopwatch = new Stopwatch();
        Stopwatch Woord12Stopwatch = new Stopwatch();
        Stopwatch Woord13Stopwatch = new Stopwatch();
        Stopwatch Woord14Stopwatch = new Stopwatch();
        Stopwatch Woord15Stopwatch = new Stopwatch();
        Stopwatch Woord16Stopwatch = new Stopwatch();
        Stopwatch Woord17Stopwatch = new Stopwatch();
        Stopwatch Woord18Stopwatch = new Stopwatch();
        Stopwatch Woord19Stopwatch = new Stopwatch();
        Stopwatch Woord20Stopwatch = new Stopwatch();
        Stopwatch Woord21Stopwatch = new Stopwatch();
        Stopwatch Woord22Stopwatch = new Stopwatch();
        /// EYE TRACKER INTERACTIE CODE
        /// 
        /// <summary>
        /// Reference to the user's eyes and head as detected
        /// by the eye-tracking device.
        /// </summary>
        private GazeInputSourcePreview gazeInputSource;

        /// <summary>
        /// Dynamic store of eye-tracking devices.
        /// </summary>
        /// <remarks>
        /// Receives event notifications when a device is added, removed, 
        /// or updated after the initial enumeration.
        /// </remarks>
        private GazeDeviceWatcherPreview gazeDeviceWatcher;

        /// <summary>
        /// Eye-tracking device counter.
        /// </summary>
        private int deviceCounter = 0;

        /// <summary>
        /// Timer for gaze focus on RadialProgressBar.
        /// </summary>
        DispatcherTimer timerGaze = new DispatcherTimer();

        /// <summary>
        /// Tracker used to prevent gaze timer restarts.
        /// </summary>
        bool timerStarted = false;

        /// <summary>
        /// Override of OnNavigatedTo page event starts GazeDeviceWatcher.
        /// </summary>
        /// <param name="e">Event args for the NavigatedTo event</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // Start listening for device events on navigation to eye-tracking page.
            StartGazeDeviceWatcher();
        }

        /// <summary>
        /// Override of OnNavigatedFrom page event stops GazeDeviceWatcher.
        /// </summary>
        /// <param name="e">Event args for the NavigatedFrom event</param>
        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            // Stop listening for device events on navigation from eye-tracking page.
            StopGazeDeviceWatcher();
        }

        /// <summary>
        /// GazeEntered handler.
        /// </summary>
        /// <param name="sender">Source of the gaze entered event</param>
        /// <param name="e">Event args for the gaze entered event</param>
        private void GazeEntered(
            GazeInputSourcePreview sender,
            GazeEnteredPreviewEventArgs args)
        {
            // Show ellipse representing gaze point.
            eyeGazePositionEllipse.Visibility = Visibility.Visible;

            // Mark the event handled.
            args.Handled = true;
        }

        /// <summary>
        /// GazeExited handler.
        /// Call DisplayRequest.RequestRelease to conclude the 
        /// RequestActive called in GazeEntered.
        /// </summary>
        /// <param name="sender">Source of the gaze exited event</param>
        /// <param name="e">Event args for the gaze exited event</param>
        private void GazeExited(
            GazeInputSourcePreview sender,
            GazeExitedPreviewEventArgs args)
        {
            // Hide gaze tracking ellipse.
            eyeGazePositionEllipse.Visibility = Visibility.Collapsed;

            // Mark the event handled.
            args.Handled = true;
        }

        /// <summary>
        /// GazeMoved handler translates the ellipse on the canvas to reflect gaze point.
        /// </summary>
        /// <param name="sender">Source of the gaze moved event</param>
        /// <param name="e">Event args for the gaze moved event</param>
        private void GazeMoved(GazeInputSourcePreview sender, GazeMovedPreviewEventArgs args)
        {
            // Update the position of the ellipse corresponding to gaze point.
            if (args.CurrentPoint.EyeGazePosition != null)
            {
                double gazePointX = args.CurrentPoint.EyeGazePosition.Value.X;
                double gazePointY = args.CurrentPoint.EyeGazePosition.Value.Y;

                double ellipseLeft =
                    gazePointX -
                    (eyeGazePositionEllipse.Width / 2.0f);
                double ellipseTop =
                    gazePointY -
                    (eyeGazePositionEllipse.Height / 2.0f);

                // Translate transform for moving gaze ellipse.
                TranslateTransform translateEllipse = new TranslateTransform
                {
                    X = ellipseLeft,
                    Y = ellipseTop
                };

                eyeGazePositionEllipse.RenderTransform = translateEllipse;

                // The gaze point screen location.
                Point gazePoint = new Point(gazePointX, gazePointY);

                // Basic hit test to determine if gaze point is on progress bar.
                bool hitBlock = DoesElementContainPoint1(gazePoint, GazeBlock.Name, GazeBlock);
                bool hitBlock2 = DoesElementContainPoint2(gazePoint, GazeBlock2.Name, GazeBlock2);
                bool hitBlock3 = DoesElementContainPoint3(gazePoint, GazeBlock3.Name, GazeBlock3);
                bool hitBlock4 = DoesElementContainPoint4(gazePoint, GazeBlock4.Name, GazeBlock4);
                bool hitBlock5 = DoesElementContainPoint5(gazePoint, GazeBlock5.Name, GazeBlock5);
                bool hitBlock6 = DoesElementContainPoint6(gazePoint, GazeBlock6.Name, GazeBlock6);
                bool hitBlock7 = DoesElementContainPoint7(gazePoint, GazeBlock7.Name, GazeBlock7);
                bool hitBlock8 = DoesElementContainPoint8(gazePoint, GazeBlock8.Name, GazeBlock8);
                bool hitBlock9 = DoesElementContainPoint9(gazePoint, GazeBlock9.Name, GazeBlock9);
                bool hitBlock10 = DoesElementContainPoint10(gazePoint, GazeBlock10.Name, GazeBlock10);
                bool hitBlock11 = DoesElementContainPoint11(gazePoint, GazeBlock11.Name, GazeBlock11);
                bool hitBlock12 = DoesElementContainPoint12(gazePoint, GazeBlock12.Name, GazeBlock12);
                bool hitBlock13 = DoesElementContainPoint13(gazePoint, GazeBlock13.Name, GazeBlock13);
                bool hitBlock14 = DoesElementContainPoint14(gazePoint, GazeBlock14.Name, GazeBlock14);
                bool hitBlock15 = DoesElementContainPoint15(gazePoint, GazeBlock15.Name, GazeBlock15);
                bool hitBlock16 = DoesElementContainPoint16(gazePoint, GazeBlock16.Name, GazeBlock16);
                bool hitBlock17 = DoesElementContainPoint17(gazePoint, GazeBlock17.Name, GazeBlock17);
                bool hitBlock18 = DoesElementContainPoint18(gazePoint, GazeBlock18.Name, GazeBlock18);
                bool hitBlock19 = DoesElementContainPoint19(gazePoint, GazeBlock19.Name, GazeBlock19);
                bool hitBlock20 = DoesElementContainPoint20(gazePoint, GazeBlock20.Name, GazeBlock20);
                bool hitBlock21 = DoesElementContainPoint21(gazePoint, GazeBlock21.Name, GazeBlock21);
                bool hitBlock22 = DoesElementContainPoint22(gazePoint, GazeBlock22.Name, GazeBlock22);
                // Mark the event handled.
                args.Handled = true;
            }
        }

        ///<summary>
        ///WOORD 1
        ///</summary>
        /// <summary>
        /// Return whether the gaze point is over the rectangle.
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint1(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.
                            
                            Woord1Stopwatch.Start();
                            
                            timerStarted = true; 
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.
           
            Woord1Stopwatch.Stop();
            
            

            timerStarted = false;
            return false;

            
            
        }
        /// <summary>
        /// WOORD 2
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint2(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord2Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord2Stopwatch.Stop();

            

            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 3
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint3(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord3Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord3Stopwatch.Stop();

        

            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 4
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint4(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord4Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord4Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 5
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint5(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord5Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord5Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 6
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint6(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord6Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord6Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 7
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint7(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord7Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord7Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 8
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint8(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord8Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord8Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 9
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint9(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord9Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord9Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 10
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint10(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord10Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord10Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 11
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint11(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord11Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord11Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 12
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint12(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord12Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord12Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 13
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint13(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord13Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord13Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 14
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint14(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord14Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord14Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 15
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint15(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord15Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord15Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 16
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint16(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord16Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord16Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 17
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint17(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord17Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord17Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 18
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint18(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord18Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord18Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 19
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint19(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord19Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord19Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
         /// WOORD 20
         /// </summary>
         /// <param name="gazePoint">The gaze point screen location</param>
         /// <param name="elementName">The progress bar name</param>
         /// <param name="uiElement">The progress bar UI element</param>
         /// <returns></returns>
        private bool DoesElementContainPoint20(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord20Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord20Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 21
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint21(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord21Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord21Stopwatch.Stop();



            timerStarted = false;
            return false;



        }
        /// <summary>
        /// WOORD 22
        /// </summary>
        /// <param name="gazePoint">The gaze point screen location</param>
        /// <param name="elementName">The progress bar name</param>
        /// <param name="uiElement">The progress bar UI element</param>
        /// <returns></returns>
        private bool DoesElementContainPoint22(
            Point gazePoint, string elementName, UIElement uiElement)

        {

            // Use entire visual tree of progress bar.
            IEnumerable<UIElement> elementStack =
              VisualTreeHelper.FindElementsInHostCoordinates(gazePoint, uiElement, true);
            foreach (UIElement item in elementStack)
            {
                //Cast to FrameworkElement and get element name.
                if (item is FrameworkElement feItem)
                {
                    if (feItem.Name.Equals(elementName))
                    {
                        if (!timerStarted)
                        {
                            // Start gaze timer if gaze over element.

                            Woord22Stopwatch.Start();

                            timerStarted = true;
                        }
                        return true;
                    }
                }
            }

            // Stop gaze timer and reset progress bar if gaze leaves element.

            Woord22Stopwatch.Stop();



            timerStarted = false;
            return false;



        }

        /// <summary>
        /// Start gaze watcher and declare watcher event handlers.
        /// </summary>
        private void StartGazeDeviceWatcher()
        {
            if (gazeDeviceWatcher == null)
            {
                gazeDeviceWatcher = GazeInputSourcePreview.CreateWatcher();
                gazeDeviceWatcher.Added += this.DeviceAdded;
                gazeDeviceWatcher.Updated += this.DeviceUpdated;
                gazeDeviceWatcher.Removed += this.DeviceRemoved;
                gazeDeviceWatcher.Start();
            }
        }

        /// <summary>
        /// Shut down gaze watcher and stop listening for events.
        /// </summary>
        private void StopGazeDeviceWatcher()
        {
            if (gazeDeviceWatcher != null)
            {
                gazeDeviceWatcher.Stop();
                gazeDeviceWatcher.Added -= this.DeviceAdded;
                gazeDeviceWatcher.Updated -= this.DeviceUpdated;
                gazeDeviceWatcher.Removed -= this.DeviceRemoved;
                gazeDeviceWatcher = null;
            }
        }

        /// <summary>
        /// Eye-tracking device connected (added, or available when watcher is initialized).
        /// </summary>
        /// <param name="sender">Source of the device added event</param>
        /// <param name="e">Event args for the device added event</param>
        private void DeviceAdded(GazeDeviceWatcherPreview source,
            GazeDeviceWatcherAddedPreviewEventArgs args)
        {
            if (IsSupportedDevice(args.Device))
            {
                deviceCounter++;

            }
            // Set up gaze tracking.
            TryEnableGazeTrackingAsync(args.Device);
        }

        /// <summary>
        /// Initial device state might be uncalibrated, 
        /// but device was subsequently calibrated.
        /// </summary>
        /// <param name="sender">Source of the device updated event</param>
        /// <param name="e">Event args for the device updated event</param>
        private void DeviceUpdated(GazeDeviceWatcherPreview source,
            GazeDeviceWatcherUpdatedPreviewEventArgs args)
        {
            // Set up gaze tracking.
            TryEnableGazeTrackingAsync(args.Device);
        }

        /// <summary>
        /// Handles disconnection of eye-tracking devices.
        /// </summary>
        /// <param name="sender">Source of the device removed event</param>
        /// <param name="e">Event args for the device removed event</param>
        private void DeviceRemoved(GazeDeviceWatcherPreview source,
            GazeDeviceWatcherRemovedPreviewEventArgs args)
        {
            // Decrement gaze device counter and remove event handlers.
            if (IsSupportedDevice(args.Device))
            {
                deviceCounter--;


                if (deviceCounter == 0)
                {
                    gazeInputSource.GazeEntered -= this.GazeEntered;
                    gazeInputSource.GazeMoved -= this.GazeMoved;
                    gazeInputSource.GazeExited -= this.GazeExited;
                }
            }
        }

        /// <summary>
        /// Initialize gaze tracking.
        /// </summary>
        /// <param name="gazeDevice"></param>
        private async void TryEnableGazeTrackingAsync(GazeDevicePreview gazeDevice)
        {
            // If eye-tracking device is ready, declare event handlers and start tracking.
            if (IsSupportedDevice(gazeDevice))
            {
                timerGaze.Interval = new TimeSpan(0, 0, 0, 0, 20);
               

                

                // This must be called from the UI thread.
                gazeInputSource = GazeInputSourcePreview.GetForCurrentView();

                gazeInputSource.GazeEntered += GazeEntered;
                gazeInputSource.GazeMoved += GazeMoved;
                gazeInputSource.GazeExited += GazeExited;
            }
            // Notify if device calibration required.
            else if (gazeDevice.ConfigurationState ==
                     GazeDeviceConfigurationStatePreview.UserCalibrationNeeded ||
                     gazeDevice.ConfigurationState ==
                     GazeDeviceConfigurationStatePreview.ScreenSetupNeeded)
            {
                // Device isn't calibrated, so invoke the calibration handler.
                System.Diagnostics.Debug.WriteLine(
                    "Your device needs to calibrate. Please wait for it to finish.");
                await gazeDevice.RequestCalibrationAsync();
            }
            // Notify if device calibration underway.
            else if (gazeDevice.ConfigurationState ==
                GazeDeviceConfigurationStatePreview.Configuring)
            {
                // Device is currently undergoing calibration.  
                // A device update is sent when calibration complete.
                System.Diagnostics.Debug.WriteLine(
                    "Your device is being configured. Please wait for it to finish");
            }
            // Device is not viable.
            else if (gazeDevice.ConfigurationState == GazeDeviceConfigurationStatePreview.Unknown)
            {
                // Notify if device is in unknown state.  
                // Reconfigure/recalbirate the device.  
                System.Diagnostics.Debug.WriteLine(
                    "Your device is not ready. Please set up your device or reconfigure it.");
            }
        }

        /// <summary>
        /// Check if eye-tracking device is viable.
        /// </summary>
        /// <param name="gazeDevice">Reference to eye-tracking device.</param>
        /// <returns>True, if device is viable; otherwise, false.</returns>
        private bool IsSupportedDevice(GazeDevicePreview gazeDevice)
        {

            return (gazeDevice.CanTrackEyes &&
                     gazeDevice.ConfigurationState ==
                     GazeDeviceConfigurationStatePreview.Ready);
        }



        /// <summary>
        /// Dit is om een bestand op te slaan waarin hij de tijd van elke stopwatch opslaat als nieuwe regel. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Create sample file; replace if exists.
            Windows.Storage.StorageFolder storageFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
            Windows.Storage.StorageFile sampleFile = await storageFolder.CreateFileAsync(Naam.Text, Windows.Storage.CreationCollisionOption.ReplaceExisting);
            await Windows.Storage.FileIO.WriteTextAsync(sampleFile, "Woord 1: " + Woord1Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 2: " + Woord2Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 3: " + Woord3Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 4: " + Woord4Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 5: " + Woord5Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 6: " + Woord6Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 7: " + Woord7Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 8: " + Woord8Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 9: " + Woord9Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 10: " + Woord10Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 11: " + Woord11Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 12: " + Woord12Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 13: " + Woord13Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 14: " + Woord14Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 15: " + Woord15Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 16: " + Woord16Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 17: " + Woord17Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 18: " + Woord18Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 19: " + Woord19Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 20: " + Woord20Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 21: " + Woord21Stopwatch.Elapsed.ToString() + Environment.NewLine + "Woord 22: " + Woord22Stopwatch.Elapsed.ToString());
            
        }
    }


}


