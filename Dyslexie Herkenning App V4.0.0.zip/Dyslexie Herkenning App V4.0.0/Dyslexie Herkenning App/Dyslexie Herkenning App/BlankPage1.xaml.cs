﻿using Microsoft.Toolkit.Uwp.Input.GazeInteraction;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Input.Preview;
using System.Diagnostics;
using Windows.Storage;
using System.Text;
using System.Collections;

namespace Dyslexie_Herkenning_App
{
    
         
    public sealed partial class BlankPage1 : Page
    {
        
        StringBuilder sb = new StringBuilder();
        
        IList<Button> Buttons = new List<Button>();
        Stopwatch Timer = new Stopwatch();
        private GazeElement[] gazeButtonControl = new GazeElement[150];
        public BlankPage1()
        {
            this.InitializeComponent();
            for (int i = 0; i < 150; i++)
            {
                Buttons.Add(FindName("Woord" + (i + 1)) as Button);
            }
            for (int i = 0; i < 150; i++)
            {
                var gazeBlock = Buttons[i];

                gazeButtonControl[i] = GazeInput.GetGazeElement(gazeBlock);
                if (gazeButtonControl[i] == null)
                {
                    gazeButtonControl[i] = new GazeElement();
                    GazeInput.SetGazeElement(gazeBlock, gazeButtonControl[i]);
                }
                gazeButtonControl[i].StateChanged += GazeBlockControl_StateChanged;
            }

        }
           
            private void GazeBlockControl_StateChanged(object sender, StateChangedEventArgs ea)
            {

                if (ea.PointerState == PointerState.Enter)
                {
                    Timer.Start();
                }

                if (ea.PointerState == PointerState.Exit)
                {
                    Timer.Stop();
                    sb.AppendLine($"{((Button)sender).Name}: {Timer.ElapsedMilliseconds}");
                    File.WriteAllText(@"C:\Users\Vincent Korpelshoek\AppData\Local\Packages\caa35555-a257-4ca1-8e35-a897ceaef7e4_v8q1h3dg62e0g\LocalState\Resultaten.txt", sb.ToString());
                    Timer.Reset();
                }
            } 
        

        //NAVIGATIE BAR
        private void MainPageButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }
        private void BlankPage1Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage1));
        }
        private void BlankPage2Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage2));
        }
        private void BlankPage3Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage3));
        }










    }
}
















